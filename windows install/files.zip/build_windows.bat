@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo  Building Infinite Battle Map for Windows
echo  (the first run downloads about 300 MB, later runs are quick)
echo ============================================================

where py >nul 2>nul
if %errorlevel%==0 (set PY=py -3) else (set PY=python)
%PY% --version >nul 2>nul
if errorlevel 1 goto :nopython

%PY% -m venv .buildenv
if errorlevel 1 goto :fail
call .buildenv\Scripts\activate.bat
python -m pip install --upgrade pip
if errorlevel 1 goto :fail
python -m pip install PySide6 pyinstaller
if errorlevel 1 goto :fail

pyinstaller --noconfirm --clean --windowed --name BattleMap --hidden-import worldgen battlemap.py
if errorlevel 1 goto :fail

powershell -NoProfile -Command "Compress-Archive -Force -Path 'dist\BattleMap\*' -DestinationPath 'BattleMap-Portable.zip'"
if errorlevel 1 goto :fail

set ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe
if exist "%ISCC%" goto :inno
echo.
echo Inno Setup is not installed, so no installer was made.
echo The zip still works: friends unzip it and double-click BattleMap.exe.
echo To also make an installer, install Inno Setup 6 from jrsoftware.org and run this again.
goto :done

:inno
"%ISCC%" installer.iss
if errorlevel 1 goto :fail

:done
echo.
echo ============================================================
echo  Finished. Share one of these with your friends:
echo    Output\BattleMap-Setup.exe   (installer, if Inno Setup was found)
echo    BattleMap-Portable.zip       (unzip and double-click BattleMap.exe)
echo ============================================================
pause
exit /b 0

:nopython
echo.
echo Python 3.10 or newer is needed to build the app.
echo Install it from python.org and tick "Add python.exe to PATH", then run this again.
pause
exit /b 1

:fail
echo.
echo Something went wrong. Scroll up to see the message above.
pause
exit /b 1
