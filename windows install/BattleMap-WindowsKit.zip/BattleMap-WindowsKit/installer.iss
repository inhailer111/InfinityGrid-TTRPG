; Inno Setup script: turns the PyInstaller build in dist\BattleMap into BattleMap-Setup.exe
[Setup]
AppName=Infinite Battle Map
AppVersion=1.0
DefaultDirName={autopf}\Battle Map
DefaultGroupName=Battle Map
OutputBaseFilename=BattleMap-Setup
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=lowest
DisableProgramGroupPage=yes
UninstallDisplayName=Infinite Battle Map

[Tasks]
Name: "desktopicon"; Description: "Put a shortcut on the desktop"

[Files]
Source: "dist\BattleMap\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion

[Icons]
Name: "{group}\Battle Map"; Filename: "{app}\BattleMap.exe"
Name: "{autodesktop}\Battle Map"; Filename: "{app}\BattleMap.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\BattleMap.exe"; Description: "Start Battle Map now"; Flags: nowait postinstall skipifsilent
