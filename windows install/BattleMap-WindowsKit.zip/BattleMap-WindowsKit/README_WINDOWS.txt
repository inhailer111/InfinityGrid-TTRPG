INFINITE BATTLE MAP - WINDOWS PACKAGING
=======================================

Keep these files together in one folder:
  battlemap.py   worldgen.py   build_windows.py   installer.iss

FOR YOUR FRIENDS
  Run BattleMap-Setup.exe and click Next. A shortcut appears on the desktop.
  (Or unzip BattleMap-Portable.zip and double-click BattleMap.exe.)
  Windows may say "Windows protected your PC" because the app is not signed.
  Click "More info", then "Run anyway". This happens once.
  Maps and token categories are saved in Documents\BattleMap.
  For the player screen, plug the TV in as a second display, then press F10.

IF YOU HAVE A WINDOWS PC
  1. Install Python 3.10 or newer from python.org (tick "Add python.exe to PATH").
  2. Optional, for a real installer: install Inno Setup 6 from jrsoftware.org.
  3. Double-click build_windows.py (or run "py build_windows.py" in this folder).
  4. Share Output\BattleMap-Setup.exe, or BattleMap-Portable.zip if there is no installer.

IF YOU DO NOT HAVE A WINDOWS PC (build it free in the cloud)
  1. Make a free account and a new, empty repository on github.com.
  2. Upload everything in this kit to it, including the hidden .github folder
     (on the repository page: Add file > Upload files, then drag the whole unzipped folder in).
  3. Open the repository's Actions tab, pick "Build Windows app" and press Run workflow.
  4. After a few minutes, open the finished run and download BattleMap-Windows.
     It contains BattleMap-Setup.exe and BattleMap-Portable.zip.
